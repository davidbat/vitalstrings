This document briefly describes the 1CLICK-1 test collection, released after NTCIR-9.


V101231CD (folder)
  nuggets (folder) -- nugget data for 4 training queries and 60 test queries
  {1C0,1C1}.qid-labels-qstr.txt -- <queryID> <querytype> <#senses> <querystring>

1C1-formal5weights.nuggets.gz -- nugget weight data based on five assessors: 
                                 <ID> <sumweights> <nuggetlen> <w1> <w2> <w3> <w4> <w5>

README.txt -- This file.



For more information , please refer to the following sources:

1CLICK-1 homepage:
http://research.microsoft.com/en-us/people/tesakai/1click.aspx
1CLICK-1 overview paper:
http://research.nii.ac.jp/ntcir/workshop/OnlineProceedings9/NTCIR/01-NTCIR9-OV-1CLICK-SakaiT.pdf
NTCIREVAL toolkit:
http://research.nii.ac.jp/ntcir/tools/ntcireval-en.html