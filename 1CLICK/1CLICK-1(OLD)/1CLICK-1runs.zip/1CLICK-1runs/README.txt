This document briefly describes the 1CLICK-1 runs and evaluation files, released after NTCIR-9.


runs (folder) -- all submitted runs

[ABIU]runs.v110829.{S-measure,W-recall}.tsmatrix.csv
                              -- query x system matrices for S-measure and W-recall with 
                                 A,B,I,U assessments (see Overview)

{CE,DE,LO,QA}.IU-SW.xlsx -- mean S-measure and W-recall (with I and U) by query type

IUAB.v110829.meean{S-measure,W-recall}.xlsx -- mean S-measure and W-recall with A,B,I,U

README.txt -- This file.


For more information , please refer to the following sources:

1CLICK-1 homepage:
http://research.microsoft.com/en-us/people/tesakai/1click.aspx
1CLICK-1 overview paper:
http://research.nii.ac.jp/ntcir/workshop/OnlineProceedings9/NTCIR/01-NTCIR9-OV-1CLICK-SakaiT.pdf
NTCIREVAL toolkit:
http://research.nii.ac.jp/ntcir/tools/ntcireval-en.html
